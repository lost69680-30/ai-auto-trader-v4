SOLO AI AUTO TRADER V4 — CANDLE ANALYSIS STAGE

What this source update does
- Adds local, read-only calculations using validated, closed backend candles:
  EMA 20/50, RSI 14, MACD 12/26/9, Bollinger Bands, ATR 14, VWAP,
  20-candle support/resistance, volume ratio, trend and momentum descriptions.
- Keeps the strategy result at HOLD; indicators do not create or authorize orders.
- Displays unavailable/insufficient data rather than inventing candle values.
- Adds lightweight source-contract tests.

Not yet verified
- The three Python source-contract tests passed in this preparation environment.
- The Android APK has NOT been compiled for this change yet. GitHub Actions must build it.
- This does not verify current backend order authorization, exchange execution, or profitability.
- Multi-timeframe analysis remains unavailable because this backend endpoint supplies one configured interval.

Phone-friendly GitHub steps
1. Upload solo-v4-candle-analysis-source-v1.zip to the repository root:
   https://github.com/lost69680-30/ai-auto-trader-v4
2. Create .github/workflows/build-solo-candle-analysis-apk.yml
3. Paste the contents of build-solo-candle-analysis-apk.yml and commit it.
4. Open Actions > Solo V4 Candle Analysis APK Build > Run workflow.
5. Wait for the workflow to finish green. Open its run, scroll to Artifacts,
   and download solo-v4-candle-analysis-debug-apk.
6. Install and test the APK. Keep paper/Testnet mode only.

Safety verification still required
- Confirm the latest authenticated backend status shows mode=PAPER_ONLY and
  orders_authorized=false. Do not paste the bearer token into chat or screenshots.
- The app's analysis panel intentionally stays BLOCKED/HOLD until authorization
  and strategy/risk workflow are separately verified. Risk checks passing in tests
  does not prove every deployed runtime path is safe.
