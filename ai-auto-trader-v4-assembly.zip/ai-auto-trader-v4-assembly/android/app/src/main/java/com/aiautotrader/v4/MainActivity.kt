package com.aiautotrader.v4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF0B1018)
private val Panel = Color(0xFF151D29)
private val Accent = Color(0xFF43D9A3)
private val Muted = Color(0xFF9BA9BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Background, surface = Panel,
                onBackground = Color(0xFFF4F7FB), onSurface = Color(0xFFF4F7FB)
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Background) { Dashboard() }
            }
        }
    }
}

@Composable
private fun Dashboard() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("AI AUTO TRADER", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(4.dp))
                Text("Trading dashboard", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            Text("v4", color = Muted, fontWeight = FontWeight.SemiBold)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("●", color = Color(0xFFFFC857), fontSize = 14.sp)
                    Text("  BACKEND NOT CONNECTED", color = Color(0xFFFFC857), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text("Paper mode only", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("This app shell is not yet connected to the Python trading service. Live balance, positions, prices, and P&L are intentionally unavailable.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }

        Text("ACCOUNT OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Paper equity", "—", "Waiting for backend", Modifier.weight(1f))
            MetricCard("Daily P&L", "—", "No account data", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Open positions", "—", "Not available", Modifier.weight(1f))
            MetricCard("Market feed", "OFFLINE", "Connection not configured", Modifier.weight(1f))
        }

        Text("SAFETY CONTROLS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SafetyRow("Exchange order execution", "DISABLED", Accent)
                SafetyRow("Risk gate", "Backend validation required", Muted)
                SafetyRow("Emergency stop", "Not connected", Color(0xFFFFC857))
            }
        }
        Text("Build milestone 1 · UI shell only. No exchange credentials are stored in this app, and no trading actions are available until authenticated backend integration and safety tests are completed.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun MetricCard(title: String, value: String, note: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(note, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun SafetyRow(label: String, status: String, color: Color) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp)
        Text(status, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
