AI AUTO TRADER V4 — PAPER-ONLY INTEGRATION BUNDLE

Contents:
- ai-auto-trader-v4-assembly.zip: updated Android + backend source, authenticated paper API and tests
- .github/workflows/build-apk.yml: corrected GitHub Actions APK build workflow
- .github/workflows/backend-tests.yml: backend safety tests on pushes and pull requests
- Dockerfile: container build for the HTTP paper service
- API_DEPLOYMENT.md: required environment settings and deployment caveats

IMPORTANT: No live order-placement endpoint or exchange credentials are included. API token must be configured as a private hosting secret. Use persistent storage mounted at /data. The Android APK is not yet wired to the deployed API; do not embed the permanent server token in a public APK.
- .github/workflows/monitor-paper-api.yml: scheduled hosted API health/status check every 15 minutes (requires GitHub Actions secrets)
