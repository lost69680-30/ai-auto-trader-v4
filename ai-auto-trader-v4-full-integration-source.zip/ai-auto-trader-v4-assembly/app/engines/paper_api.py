"""Authenticated HTTP control/status API for the paper-only runtime.

The API has no exchange order endpoint. Market polling runs in a supervised
background thread; controls require a bearer token. /health is deliberately
minimal and contains no portfolio or configuration data.
"""
from __future__ import annotations

from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import logging
import os
from threading import Event, Lock, Thread
import time
from typing import Any, Callable

from app.engines.paper_service_app import PaperServiceApplication, PaperServiceAnalysisResult
from app.engines.paper_runtime import PaperRuntimeReport

logger = logging.getLogger(__name__)


def _safe_report(report: PaperRuntimeReport[Any] | None) -> dict[str, Any] | None:
    if report is None:
        return None
    return {
        "checked_at": report.checked_at,
        "analysis_status": str(report.analysis_status),
        "healthy_symbols": list(report.healthy_symbols),
        "unhealthy_symbols": list(report.unhealthy_symbols),
        "fill_statuses": [list(item) for item in report.fill_statuses],
        "protection_status": str(report.protection_status),
        "open_positions": int(report.open_positions),
        "orders_authorized": False,
    }


@dataclass
class RuntimeState:
    lock: Lock
    last_report: PaperRuntimeReport[Any] | None = None
    last_error: str | None = None
    started_at: float = 0.0
    worker_alive: bool = False

    @classmethod
    def create(cls) -> "RuntimeState":
        return cls(lock=Lock(), started_at=time.time())

    def record_report(self, report: PaperRuntimeReport[Any]) -> None:
        with self.lock:
            self.last_report = report
            self.last_error = None
            self.worker_alive = True

    def record_error(self, exc: BaseException) -> None:
        # Avoid returning exception details that could contain internal paths/config.
        with self.lock:
            self.last_error = type(exc).__name__

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "service": "ai-auto-trader-paper-api",
                "mode": "PAPER_ONLY",
                "worker_alive": self.worker_alive,
                "started_at": self.started_at,
                "last_error_type": self.last_error,
                "last_report": _safe_report(self.last_report),
                "orders_authorized": False,
            }


def make_handler(*, state: RuntimeState, service: PaperServiceApplication,
                 api_token: str) -> type[BaseHTTPRequestHandler]:
    if not isinstance(api_token, str) or len(api_token) < 32:
        raise ValueError("PAPER_API_TOKEN must contain at least 32 characters")

    class Handler(BaseHTTPRequestHandler):
        server_version = "AI-Auto-Trader-Paper/1.0"

        def log_message(self, fmt: str, *args: object) -> None:
            logger.info("api %s - %s", self.address_string(), fmt % args)

        def _json(self, status: int, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _authorized(self) -> bool:
            value = self.headers.get("Authorization", "")
            if not value.startswith("Bearer "):
                return False
            return hmac.compare_digest(value[7:].encode(), api_token.encode())

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                self._json(200, {"ok": True, "mode": "PAPER_ONLY", "orders_authorized": False})
                return
            if self.path == "/api/status":
                if not self._authorized():
                    self._json(401, {"error": "unauthorized"})
                    return
                self._json(200, state.snapshot())
                return
            self._json(404, {"error": "not_found"})

        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/api/emergency-stop":
                self._json(404, {"error": "not_found"})
                return
            if not self._authorized():
                self._json(401, {"error": "unauthorized"})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > 4096:
                    self._json(400, {"error": "invalid_body_size"})
                    return
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8"))
                reason = payload.get("reason") if isinstance(payload, dict) else None
                if not isinstance(reason, str) or not reason.strip() or len(reason) > 500:
                    self._json(400, {"error": "reason_required"})
                    return
                cancelled = service.activate_emergency_stop(reason=reason.strip())
                self._json(200, {
                    "status": "EMERGENCY_STOP_ACTIVE",
                    "cancelled_paper_intents": list(cancelled),
                    "orders_authorized": False,
                })
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                self._json(400, {"error": "invalid_json"})
            except Exception as exc:  # fail closed; do not leak internals
                logger.exception("emergency stop request failed")
                state.record_error(exc)
                self._json(503, {"error": "emergency_stop_unavailable", "orders_authorized": False})

    return Handler


class PaperApiServer:
    """Lifecycle wrapper for a threaded HTTP API and paper market worker."""

    def __init__(self, service: PaperServiceApplication, *, host: str, port: int,
                 api_token: str) -> None:
        self.service = service
        self.state = RuntimeState.create()
        self.stop_event = Event()
        self._worker_thread = Thread(target=self._run_worker, name="paper-market-worker", daemon=True)
        self.httpd = ThreadingHTTPServer((host, port), make_handler(
            state=self.state, service=service, api_token=api_token,
        ))
        self.httpd.daemon_threads = True

    def _run_worker(self) -> None:
        self.state.worker_alive = True
        try:
            self.service.run_forever(self.stop_event, on_report=self.state.record_report)
        except Exception as exc:
            logger.exception("paper market worker stopped unexpectedly")
            self.state.record_error(exc)
            self.state.worker_alive = False

    def serve_forever(self) -> None:
        self._worker_thread.start()
        logger.info("paper API listening on %s:%s", *self.httpd.server_address)
        try:
            self.httpd.serve_forever(poll_interval=0.5)
        finally:
            self._cleanup(shutdown=False)

    def _cleanup(self, *, shutdown: bool) -> None:
        self.stop_event.set()
        if shutdown:
            self.httpd.shutdown()
        self.httpd.server_close()
        if self._worker_thread.is_alive():
            self._worker_thread.join(timeout=10)
        self.service.close()

    def close(self) -> None:
        self._cleanup(shutdown=True)


def main() -> None:
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    token = os.getenv("PAPER_API_TOKEN", "")
    if len(token) < 32:
        raise SystemExit("PAPER_API_TOKEN must be configured with at least 32 random characters")
    host = os.getenv("PAPER_API_HOST", "0.0.0.0")
    port_text = os.getenv("PORT", os.getenv("PAPER_API_PORT", "8000"))
    try:
        port = int(port_text)
    except ValueError as exc:
        raise SystemExit("PORT must be an integer") from exc
    if not 1 <= port <= 65535:
        raise SystemExit("PORT must be between 1 and 65535")
    service = PaperServiceApplication.from_env()
    server = PaperApiServer(service, host=host, port=port, api_token=token)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        # serve_forever already closes during normal server shutdown.
        if not getattr(server.service, "_closed", False):
            server.close()


if __name__ == "__main__":
    main()
