"""Risk-boundary planner and maximum favorable/adverse excursion tracker.

Pure calculations only. This module cannot submit, cancel, or modify exchange orders.
All percentage inputs are percentages (e.g. 1.5 means 1.5%), not fractions.
"""
from __future__ import annotations
from dataclasses import dataclass
import math


@dataclass(frozen=True, slots=True)
class RiskBoundaries:
    side: str
    entry: float
    stop_loss: float
    take_profit: float
    risk_per_unit: float
    reward_per_unit: float
    reward_risk_ratio: float
    status: str = "PLAN_ONLY"
    orders_authorized: bool = False


@dataclass(frozen=True, slots=True)
class ExcursionState:
    side: str
    entry: float
    last_price: float
    mfe_price: float
    mae_price: float
    mfe_pct: float
    mae_pct: float
    mfe_r: float
    mae_r: float
    trailing_stop: float | None
    status: str = "OBSERVE_ONLY"
    orders_authorized: bool = False


def _positive(name: str, value: float) -> None:
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")


def plan_boundaries(*, side: str, entry: float, atr: float, atr_multiple: float = 1.5,
                    reward_risk: float = 2.0, support: float | None = None,
                    resistance: float | None = None) -> RiskBoundaries:
    """Create ATR-based SL/TP boundaries, optionally tightened to nearby structure."""
    side = side.upper()
    if side not in {"LONG", "SHORT"}:
        raise ValueError("side must be LONG or SHORT")
    _positive("entry", entry); _positive("atr", atr); _positive("atr_multiple", atr_multiple); _positive("reward_risk", reward_risk)
    if support is not None: _positive("support", support)
    if resistance is not None: _positive("resistance", resistance)
    distance = atr * atr_multiple
    if side == "LONG":
        stop = entry - distance
        if support is not None and support < entry:
            stop = max(stop, support)
        if stop <= 0 or stop >= entry:
            raise ValueError("no valid long stop boundary below entry")
        risk = entry - stop
        target = entry + risk * reward_risk
        if resistance is not None and resistance > entry:
            target = min(target, resistance)
        if target <= entry:
            raise ValueError("resistance leaves no positive reward distance")
    else:
        stop = entry + distance
        if resistance is not None and resistance > entry:
            stop = min(stop, resistance)
        if stop <= entry:
            raise ValueError("no valid short stop boundary above entry")
        risk = stop - entry
        target = entry - risk * reward_risk
        if support is not None and support < entry:
            target = max(target, support)
        if target <= 0 or target >= entry:
            raise ValueError("no valid short take-profit boundary below entry")
    reward = abs(target - entry)
    return RiskBoundaries(side, entry, stop, target, risk, reward, reward / risk)


def update_excursion(*, side: str, entry: float, price: float, risk_per_unit: float,
                     prior_mfe_price: float | None = None, prior_mae_price: float | None = None,
                     trailing_distance_pct: float | None = None, prior_trailing_stop: float | None = None) -> ExcursionState:
    """Update MFE/MAE and a ratcheting-only trailing stop from an observed price."""
    side = side.upper()
    if side not in {"LONG", "SHORT"}: raise ValueError("side must be LONG or SHORT")
    for n, v in (("entry", entry), ("price", price), ("risk_per_unit", risk_per_unit)):
        _positive(n, v)
    if trailing_distance_pct is not None and (not math.isfinite(trailing_distance_pct) or not 0 < trailing_distance_pct < 100):
        raise ValueError("trailing_distance_pct must be between 0 and 100 percent")
    mfe = max(entry, price, prior_mfe_price or entry) if side == "LONG" else min(entry, price, prior_mfe_price or entry)
    mae = min(entry, price, prior_mae_price or entry) if side == "LONG" else max(entry, price, prior_mae_price or entry)
    mfe_pct = ((mfe / entry - 1) * 100) if side == "LONG" else ((entry / mfe - 1) * 100)
    mae_pct = ((mae / entry - 1) * 100) if side == "LONG" else ((entry / mae - 1) * 100)
    mfe_r = (mfe - entry) / risk_per_unit if side == "LONG" else (entry - mfe) / risk_per_unit
    mae_r = (mae - entry) / risk_per_unit if side == "LONG" else (entry - mae) / risk_per_unit
    trailing = prior_trailing_stop
    if trailing_distance_pct is not None:
        candidate = mfe * (1 - trailing_distance_pct / 100) if side == "LONG" else mfe * (1 + trailing_distance_pct / 100)
        if side == "LONG": trailing = max([x for x in (prior_trailing_stop, candidate) if x is not None])
        else: trailing = min([x for x in (prior_trailing_stop, candidate) if x is not None])
    return ExcursionState(side, entry, price, mfe, mae, mfe_pct, mae_pct, mfe_r, mae_r, trailing)
