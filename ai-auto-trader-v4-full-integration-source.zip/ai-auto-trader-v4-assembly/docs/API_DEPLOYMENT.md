# Paper API and automation deployment

This adds an authenticated HTTP wrapper around the existing paper runtime. It runs the existing market-data worker continuously and exposes health/status plus a paper emergency-stop endpoint. It has no exchange order-placement endpoint and no exchange credentials.

## Endpoints

- `GET /health` — minimal liveness response; always declares `PAPER_ONLY` and `orders_authorized: false`.
- `GET /api/status` — bearer-token protected worker and latest-cycle status.
- `POST /api/emergency-stop` — bearer-token protected durable paper emergency stop. JSON body: `{"reason":"operator requested"}`.
- Unknown paths return 404. Missing/invalid tokens return 401. Status and emergency-stop errors fail closed.

## Required environment

Set all paper risk variables from `.env.paper.example` explicitly. Also set `PAPER_API_TOKEN` to a randomly generated secret of at least 32 characters, `PORT=8000` (or the host's assigned port), and `PAPER_DATABASE_PATH=/data/paper-ledger.sqlite3`. Never commit the token or any exchange secret. There are no exchange order credentials or signed order endpoints in this application.

Run locally after setting environment variables:

```bash
python -m app.engines.paper_api
curl http://127.0.0.1:8000/health
curl -H "Authorization: Bearer $PAPER_API_TOKEN" http://127.0.0.1:8000/api/status
curl -X POST -H "Authorization: Bearer $PAPER_API_TOKEN" -H 'Content-Type: application/json' -d '{"reason":"operator requested"}' http://127.0.0.1:8000/api/emergency-stop
```

## Hosting requirements and caveats

Use a container host that supports a continuously running web service and a persistent disk mounted at `/data`. A host with ephemeral filesystem can lose the SQLite ledger on restart and is not suitable for durable paper state. Do not expose this API over plain HTTP on an untrusted network; terminate TLS at the hosting platform. Rotate the bearer token if exposed. Add platform-level access controls and monitoring before use outside a private test.

The `PAPER_MARKET_TESTNET` switch selects a public market-data host only. It does not activate exchange trading. Market data connectivity, worker health, database durability, and emergency-stop behavior must be checked on the actual host before treating the deployment as operational. This API status wrapper is not yet an Android app connection; the Android client must be configured with the deployed HTTPS base URL and securely supplied token before it can display backend status.
