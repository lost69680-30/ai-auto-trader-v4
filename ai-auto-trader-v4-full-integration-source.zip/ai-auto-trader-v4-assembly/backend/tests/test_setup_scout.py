from datetime import datetime, timedelta, timezone
from backend.strategy_research import Candle
from backend.setup_scout import ScoutConfig, scout_setups, scan_markets

NOW = datetime(2026, 10, 14, 12, 0, tzinfo=timezone.utc)

def candles(symbol="BTC/USDT", last_close=109.8):
    rows=[]
    start=NOW-timedelta(minutes=23)
    for i in range(24):
        close=100 + (i % 4) * .1
        high=close+1
        low=close-1
        if i == 22:
            close=108; high=110; low=107
        if i == 23:
            close=last_close; high=max(110.1,last_close+.2); low=min(109.5,last_close-.2)
        rows.append(Candle(symbol,start+timedelta(minutes=i),close,high,low,close,100+(i%3)*5))
    return rows

def test_scout_outputs_watch_only_and_no_orders():
    cfg=ScoutConfig(min_history=24, range_lookback=20, atr_period=14, max_range_pct=20)
    result=scout_setups("BTC/USDT", candles(), now=NOW, config=cfg)
    assert all(s.status == "WATCH_ONLY" and not s.orders_authorized for s in result)
    assert all(s.stop_loss is not None and s.take_profit is not None for s in result)

def test_scan_rejects_stale_history():
    old=[c for c in candles()]
    old[-1]=Candle(old[-1].symbol,NOW-timedelta(hours=1),old[-1].open,old[-1].high,old[-1].low,old[-1].close,old[-1].volume)
    result=scan_markets({"BTC/USDT":old},now=NOW)
    assert result.rejected_symbols and not result.setups and not result.orders_authorized

def test_future_timestamp_rejected():
    rows=candles(); c=rows[-1]
    rows[-1]=Candle(c.symbol,NOW+timedelta(minutes=1),c.open,c.high,c.low,c.close,c.volume)
    assert scout_setups("BTC/USDT",rows,now=NOW)==()
