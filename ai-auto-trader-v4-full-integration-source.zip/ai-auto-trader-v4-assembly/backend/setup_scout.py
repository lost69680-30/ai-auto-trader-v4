"""Early-setup scouts and market scan engine (research-only, fail-closed).

Detects pre-breakout compression, range-edge approaches, and confirmed range breaks.
Scores are deterministic screening heuristics, not probabilities or trade instructions.
No exchange, account, or order-placement interface exists in this module.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import math
from typing import Iterable

from backend.strategy_research import Candle


@dataclass(frozen=True, slots=True)
class ScoutConfig:
    min_history: int = 24
    range_lookback: int = 20
    atr_period: int = 14
    max_candle_age_seconds: int = 180
    max_range_pct: float = 3.0
    near_boundary_atr: float = 0.6
    breakout_buffer_atr: float = 0.1
    min_volume_ratio: float = 1.2
    stop_atr_multiple: float = 1.5
    target_r_multiple: float = 2.0

    def __post_init__(self) -> None:
        if self.min_history < 5 or self.range_lookback < 3 or self.atr_period < 2:
            raise ValueError("history and indicator periods are too small")
        if self.min_history < max(self.range_lookback + 1, self.atr_period + 1):
            raise ValueError("min_history must cover range and ATR lookbacks")
        if self.max_candle_age_seconds <= 0:
            raise ValueError("max_candle_age_seconds must be positive")
        for name in ("max_range_pct", "near_boundary_atr", "breakout_buffer_atr", "min_volume_ratio", "stop_atr_multiple", "target_r_multiple"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")


@dataclass(frozen=True, slots=True)
class SetupScout:
    symbol: str
    setup: str
    direction: str
    score: float
    reference_price: float
    support: float
    resistance: float
    stop_loss: float | None
    take_profit: float | None
    reasons: tuple[str, ...]
    status: str = "WATCH_ONLY"
    orders_authorized: bool = False


@dataclass(frozen=True, slots=True)
class ScoutScanResult:
    setups: tuple[SetupScout, ...]
    rejected_symbols: tuple[tuple[str, str], ...]
    orders_authorized: bool = False


def _atr(candles: list[Candle], period: int) -> float:
    trs = []
    for i in range(1, len(candles)):
        c, prev = candles[i], candles[i - 1]
        trs.append(max(c.high - c.low, abs(c.high - prev.close), abs(c.low - prev.close)))
    return sum(trs[-period:]) / period


def _validate(symbol: str, rows: list[Candle], now: datetime, cfg: ScoutConfig) -> str | None:
    if not symbol.strip() or len(rows) < cfg.min_history:
        return f"insufficient history: need at least {cfg.min_history} candles"
    previous = None
    for c in rows:
        if c.symbol != symbol:
            return "mixed or mismatched symbols"
        if c.timestamp.tzinfo is None or c.timestamp.utcoffset() is None:
            return "candle timestamp must be timezone-aware"
        ts = c.timestamp.astimezone(timezone.utc)
        if previous is not None and ts <= previous:
            return "candle timestamps must be strictly increasing"
        previous = ts
        vals = (c.open, c.high, c.low, c.close, c.volume)
        if not all(math.isfinite(v) for v in vals):
            return "non-finite candle data"
        if min(c.open, c.high, c.low, c.close) <= 0 or c.volume < 0:
            return "prices must be positive and volume non-negative"
        if c.high < max(c.open, c.close, c.low) or c.low > min(c.open, c.close, c.high):
            return "inconsistent OHLC candle"
    age = (now.astimezone(timezone.utc) - rows[-1].timestamp.astimezone(timezone.utc)).total_seconds()
    if age < -2:
        return "latest candle is from the future"
    if age > cfg.max_candle_age_seconds:
        return "latest candle is stale"
    return None


def scout_setups(symbol: str, candles: Iterable[Candle], *, now: datetime, config: ScoutConfig | None = None) -> tuple[SetupScout, ...]:
    """Return zero or more watch-only setups; invalid data returns no setup."""
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    cfg = config or ScoutConfig()
    rows = list(candles)
    if _validate(symbol, rows, now, cfg):
        return ()
    last = rows[-1]
    window = rows[-cfg.range_lookback-1:-1]  # excludes current candle to avoid look-ahead
    support = min(c.low for c in window)
    resistance = max(c.high for c in window)
    atr = _atr(rows, cfg.atr_period)
    if not math.isfinite(atr) or atr <= 0 or resistance <= support:
        return ()
    range_pct = (resistance - support) / last.close * 100
    avg_volume = sum(c.volume for c in window) / len(window)
    volume_ratio = last.volume / avg_volume if avg_volume > 0 else 0.0
    near = cfg.near_boundary_atr * atr
    buffer = cfg.breakout_buffer_atr * atr
    out: list[SetupScout] = []

    def add(setup: str, direction: str, score: float, reasons: tuple[str, ...], stop: float, target: float) -> None:
        # The levels are educational planning boundaries only, not an order request.
        if stop <= 0 or target <= 0 or (direction == "LONG" and not stop < last.close < target) or (direction == "SHORT" and not target < last.close < stop):
            return
        out.append(SetupScout(symbol, setup, direction, round(max(0.0, min(100.0, score)), 2), last.close,
                              support, resistance, round(stop, 10), round(target, 10), reasons))

    if range_pct <= cfg.max_range_pct:
        if last.close >= resistance - near and last.close <= resistance + buffer:
            add("PRE_BREAKOUT_RESISTANCE", "LONG", 55 + min(20, volume_ratio * 5),
                ("price is approaching the prior range ceiling", f"range width {range_pct:.2f}%", f"volume ratio {volume_ratio:.2f}x", "breakout not confirmed"),
                min(support, last.close - cfg.stop_atr_multiple * atr), last.close + cfg.target_r_multiple * cfg.stop_atr_multiple * atr)
        if last.close <= support + near and last.close >= support - buffer:
            add("PRE_BREAKDOWN_SUPPORT", "SHORT", 55 + min(20, volume_ratio * 5),
                ("price is approaching the prior range floor", f"range width {range_pct:.2f}%", f"volume ratio {volume_ratio:.2f}x", "breakdown not confirmed"),
                max(resistance, last.close + cfg.stop_atr_multiple * atr), last.close - cfg.target_r_multiple * cfg.stop_atr_multiple * atr)
    if last.close > resistance + buffer:
        score = 60 + min(20, max(0, volume_ratio - 1) * 10)
        add("RANGE_BREAKOUT", "LONG", score, ("close exceeded prior resistance", f"volume ratio {volume_ratio:.2f}x", "confirmation and risk review still required"),
            last.close - cfg.stop_atr_multiple * atr, last.close + cfg.target_r_multiple * cfg.stop_atr_multiple * atr)
    if last.close < support - buffer:
        score = 60 + min(20, max(0, volume_ratio - 1) * 10)
        add("RANGE_BREAKDOWN", "SHORT", score, ("close fell below prior support", f"volume ratio {volume_ratio:.2f}x", "confirmation and risk review still required"),
            last.close + cfg.stop_atr_multiple * atr, last.close - cfg.target_r_multiple * cfg.stop_atr_multiple * atr)
    return tuple(sorted(out, key=lambda s: (-s.score, s.setup)))


def scan_markets(markets: dict[str, Iterable[Candle]], *, now: datetime, config: ScoutConfig | None = None) -> ScoutScanResult:
    """Scan multiple symbols independently; malformed symbols are rejected, never authorized."""
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    cfg = config or ScoutConfig()
    found: list[SetupScout] = []
    rejected: list[tuple[str, str]] = []
    for symbol, candles in markets.items():
        rows = list(candles)
        reason = _validate(symbol, rows, now, cfg)
        if reason:
            rejected.append((symbol, reason))
            continue
        found.extend(scout_setups(symbol, rows, now=now, config=cfg))
    found.sort(key=lambda s: (-s.score, s.symbol, s.setup))
    rejected.sort()
    return ScoutScanResult(tuple(found), tuple(rejected), False)
