from dataclasses import replace

import pytest

from app.core.models import MarketSnapshot, RiskLimits, TradeProposal
from app.engines.orchestrator import (
    OrchestrationRequest, PaperOrderIntent, TradingOrchestrator,
)
from backend.signal_validation import SignalValidationResult
from backend.signal_watcher import WatchResult
from app.engines.paper_ledger import SQLitePaperLedger


def make_intent(**changes):
    intent = PaperOrderIntent(
        proposal_id="proposal-1",
        signal_id="signal-1",
        symbol="BTCUSDT",
        side="LONG",
        quantity=0.01,
        entry_price=50_000,
        stop_loss=49_000,
        take_profit=52_000,
        recorded_at=1000,
    )
    return replace(intent, **changes)


def test_intent_is_persisted_and_restored_after_reopen(tmp_path):
    path = tmp_path / "paper.db"
    ledger = SQLitePaperLedger(path)
    assert ledger.record_intent(make_intent()) == "RECORDED"
    ledger.close()

    recovered = SQLitePaperLedger(path)
    assert len(recovered.orders) == 1
    assert recovered.orders[0].proposal_id == "proposal-1"
    assert recovered.orders[0].status == "PENDING_PAPER_SIMULATION"
    assert recovered.orders_authorized is False
    recovered.close()


def test_same_intent_is_idempotent_but_changed_reuse_conflicts(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    intent = make_intent()
    assert ledger.record_intent(intent) == "RECORDED"
    assert ledger.record_intent(intent) == "DUPLICATE"
    assert ledger.record_intent(replace(intent, quantity=0.02)) == "CONFLICT"
    assert len(ledger.orders) == 1
    ledger.close()


def test_simulated_fill_creates_fill_and_open_position_with_adverse_slippage(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    ledger.record_intent(make_intent())

    result = ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001, fee_rate=0.001, slippage_bps=10)

    assert result.status == "FILLED"
    assert result.orders_authorized is False
    assert result.fill.price == pytest.approx(50_050)
    assert result.fill.fee == pytest.approx(0.5005)
    assert result.position.status == "OPEN"
    assert result.position.entry_price == pytest.approx(50_050)
    assert len(ledger.fills) == 1
    assert len(ledger.open_positions) == 1
    assert ledger.orders[0].status == "FILLED"
    ledger.close()


def test_fill_idempotency_survives_process_restart(tmp_path):
    path = tmp_path / "paper.db"
    ledger = SQLitePaperLedger(path)
    ledger.record_intent(make_intent())
    first = ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001)
    assert first.status == "FILLED"
    ledger.close()

    recovered = SQLitePaperLedger(path)
    repeated = recovered.simulate_fill("proposal-1", market_price=50_000, filled_at=1001)
    conflicting = recovered.simulate_fill("proposal-1", market_price=50_100, filled_at=1002)
    assert repeated.status == "ALREADY_FILLED"
    assert conflicting.status == "FILL_CONFLICT"
    assert len(recovered.fills) == 1
    assert len(recovered.open_positions) == 1
    recovered.close()


def test_short_fill_and_mark_to_market_use_short_pnl_sign(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    ledger.record_intent(make_intent(side="SHORT", entry_price=50_000, stop_loss=51_000, take_profit=48_000))
    ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001, fee_rate=0, slippage_bps=0)

    marked = ledger.mark_positions({"BTCUSDT": 49_000}, observed_at=1002)
    assert marked[0].unrealized_pnl == pytest.approx(10)
    with pytest.raises(ValueError, match="older"):
        ledger.mark_positions({"BTCUSDT": 51_000}, observed_at=1001)
    assert ledger.positions[0].mark_price == pytest.approx(49_000)
    ledger.close()


def test_closing_position_persists_net_realized_pnl_and_is_idempotent(tmp_path):
    path = tmp_path / "paper.db"
    ledger = SQLitePaperLedger(path)
    ledger.record_intent(make_intent())
    ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001, fee_rate=0.001, slippage_bps=0)

    result = ledger.close_position("proposal-1", market_price=51_000, closed_at=1002, fee_rate=0.001, slippage_bps=0)
    assert result.status == "CLOSED"
    assert result.position.status == "CLOSED"
    assert result.position.realized_pnl == pytest.approx(8.99)
    assert result.position.unrealized_pnl == 0
    assert result.position.close_price == pytest.approx(51_000)
    assert ledger.open_positions == ()
    assert ledger.orders[0].status == "CLOSED"
    repeated = ledger.close_position("proposal-1", market_price=51_000, closed_at=1002, fee_rate=0.001, slippage_bps=0)
    assert repeated.status == "ALREADY_CLOSED"
    ledger.close()

    recovered = SQLitePaperLedger(path)
    assert recovered.positions[0].status == "CLOSED"
    assert recovered.positions[0].realized_pnl == pytest.approx(8.99)
    recovered.close()


def test_invalid_fill_and_unknown_order_do_not_change_ledger(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    assert ledger.simulate_fill("missing", market_price=50_000, filled_at=1001).status == "NOT_FOUND"
    ledger.record_intent(make_intent())
    for kwargs in (
        {"market_price": 0, "filled_at": 1001},
        {"market_price": float("nan"), "filled_at": 1001},
        {"market_price": True, "filled_at": 1001},
        {"market_price": 50_000, "filled_at": 1001, "fee_rate": -0.1},
        {"market_price": 50_000, "filled_at": 1001, "slippage_bps": 10_000},
        {"market_price": 50_000, "filled_at": 999},
    ):
        with pytest.raises(ValueError):
            ledger.simulate_fill("proposal-1", **kwargs)
    assert ledger.fills == ()
    assert ledger.positions == ()
    assert ledger.orders[0].status == "PENDING_PAPER_SIMULATION"
    ledger.close()


def test_orchestrator_can_record_to_durable_ledger(tmp_path):
    # The same ledger contract is used by the orchestrator; no exchange client exists here.
    proposal = TradeProposal("proposal-1", "BTCUSDT", "LONG", 0.01, 50_000, 49_000, 52_000, 10, 1000)
    request = OrchestrationRequest(
        proposal=proposal,
        market=MarketSnapshot("BTCUSDT", 50_000, 1000, True),
        validation=SignalValidationResult(
            signal_id="signal-1", symbol="BTCUSDT", direction="LONG", status="VALID",
            reasons=(), agreeing_strategies=("trend",), opposing_strategies=(),
            gross_reward_risk=2, net_reward_risk=1.8,
        ),
        watch_result=WatchResult("watch-1", "signal-1", "BTCUSDT", "TRIGGERED", "test", True, 50_000),
        limits=RiskLimits(1000, 100, 3, 20), daily_pnl=0, open_positions=0, now=1000,
    )

    path = tmp_path / "orchestrated.db"
    ledger = SQLitePaperLedger(path)
    result = TradingOrchestrator(ledger).process(request)
    assert result.status == "PAPER_ORDER_RECORDED"
    ledger.close()

    recovered = SQLitePaperLedger(path)
    assert len(recovered.orders) == 1
    assert recovered.fills == ()
    recovered.close()


def test_fill_is_blocked_if_slippage_puts_price_outside_protection_geometry(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    ledger.record_intent(make_intent())

    result = ledger.simulate_fill(
        "proposal-1", market_price=52_000, filled_at=1001, fee_rate=0, slippage_bps=0
    )

    assert result.status == "FILL_BLOCKED_BY_PROTECTION"
    assert ledger.fills == ()
    assert ledger.open_positions == ()
    assert ledger.orders[0].status == "PENDING_PAPER_SIMULATION"
    ledger.close()


def test_close_before_last_accepted_mark_is_rejected_atomically(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    ledger.record_intent(make_intent())
    ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001, fee_rate=0, slippage_bps=0)
    ledger.mark_positions({"BTCUSDT": 50_100}, observed_at=1003)

    with pytest.raises(ValueError, match="last accepted mark"):
        ledger.close_position("proposal-1", market_price=50_200, closed_at=1002, fee_rate=0, slippage_bps=0)

    assert ledger.open_positions[0].mark_price == pytest.approx(50_100)
    assert ledger.audit_events[-1].event_type == "PAPER_POSITION_MARKED"
    ledger.close()


def test_audit_events_survive_restart(tmp_path):
    path = tmp_path / "paper.db"
    ledger = SQLitePaperLedger(path)
    ledger.record_intent(make_intent())
    ledger.simulate_fill("proposal-1", market_price=50_000, filled_at=1001, fee_rate=0, slippage_bps=0)
    assert [event.event_type for event in ledger.audit_events] == [
        "PAPER_ORDER_INTENT_RECORDED", "PAPER_FILL_SIMULATED"
    ]
    ledger.close()

    recovered = SQLitePaperLedger(path)
    assert [event.event_type for event in recovered.audit_events] == [
        "PAPER_ORDER_INTENT_RECORDED", "PAPER_FILL_SIMULATED"
    ]
    recovered.close()


def test_short_fill_and_close_apply_adverse_slippage_on_both_sides(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    ledger.record_intent(make_intent(side="SHORT", entry_price=50_000, stop_loss=51_000, take_profit=48_000))

    filled = ledger.simulate_fill(
        "proposal-1", market_price=50_000, filled_at=1001, fee_rate=0, slippage_bps=10
    )
    closed = ledger.close_position(
        "proposal-1", market_price=49_000, closed_at=1002, fee_rate=0, slippage_bps=10
    )

    assert filled.fill.price == pytest.approx(49_950)
    assert closed.position.close_price == pytest.approx(49_049)
    assert closed.position.realized_pnl == pytest.approx(9.01)
    ledger.close()


def test_order_authorization_is_read_only_and_false(tmp_path):
    ledger = SQLitePaperLedger(tmp_path / "paper.db")
    assert ledger.orders_authorized is False
    with pytest.raises(AttributeError):
        ledger.orders_authorized = True
    ledger.close()


def test_file_backed_ledger_creates_missing_parent_directories(tmp_path):
    database = tmp_path / "data" / "paper" / "account.sqlite3"
    ledger = SQLitePaperLedger(database)
    ledger.record_intent(make_intent())
    ledger.close()

    assert database.is_file()
    recovered = SQLitePaperLedger(database)
    assert len(recovered.orders) == 1
    recovered.close()
