import pytest
from app.engines.boundary_excursion import plan_boundaries, update_excursion

def test_long_boundaries_and_excursion():
    plan=plan_boundaries(side="LONG",entry=100,atr=2,atr_multiple=1.5,reward_risk=2)
    assert plan.stop_loss < 100 < plan.take_profit
    state=update_excursion(side="LONG",entry=100,price=105,risk_per_unit=3,trailing_distance_pct=1)
    assert state.mfe_price == 105 and state.mfe_r > 0 and state.trailing_stop == pytest.approx(103.95)

def test_short_trailing_stop_ratchets_down_then_never_widens():
    first=update_excursion(side="SHORT",entry=100,price=95,risk_per_unit=3,trailing_distance_pct=1)
    second=update_excursion(side="SHORT",entry=100,price=97,risk_per_unit=3,prior_mfe_price=first.mfe_price,prior_mae_price=first.mae_price,trailing_distance_pct=1,prior_trailing_stop=first.trailing_stop)
    assert first.trailing_stop == pytest.approx(95.95)
    assert second.trailing_stop == first.trailing_stop

def test_invalid_boundary_rejected():
    with pytest.raises(ValueError): plan_boundaries(side="LONG",entry=100,atr=100)

def test_invalid_price_rejected():
    with pytest.raises(ValueError): update_excursion(side="LONG",entry=100,price=0,risk_per_unit=1)
