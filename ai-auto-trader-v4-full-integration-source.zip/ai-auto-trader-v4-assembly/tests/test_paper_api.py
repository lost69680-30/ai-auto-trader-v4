import json
from http.client import HTTPConnection
from threading import Thread
from http.server import ThreadingHTTPServer

from app.engines.paper_api import RuntimeState, make_handler

TOKEN = "test-token-which-is-longer-than-thirty-two-characters"


class FakeService:
    def __init__(self):
        self.reasons = []

    def activate_emergency_stop(self, *, reason):
        self.reasons.append(reason)
        return ("paper-intent-1",)


def running_api():
    state = RuntimeState.create()
    service = FakeService()
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(state=state, service=service, api_token=TOKEN))
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread, state, service


def request(server, method, path, body=None, token=None):
    conn = HTTPConnection("127.0.0.1", server.server_port, timeout=2)
    headers = {}
    payload = None
    if body is not None:
        payload = json.dumps(body)
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = "Bearer " + token
    conn.request(method, path, body=payload, headers=headers)
    response = conn.getresponse()
    result = response.status, json.loads(response.read().decode())
    conn.close()
    return result


def test_health_is_minimal_and_paper_only():
    server, thread, _, _ = running_api()
    try:
        status, body = request(server, "GET", "/health")
        assert status == 200
        assert body == {"ok": True, "mode": "PAPER_ONLY", "orders_authorized": False}
    finally:
        server.shutdown(); server.server_close(); thread.join()


def test_status_requires_bearer_token():
    server, thread, _, _ = running_api()
    try:
        assert request(server, "GET", "/api/status")[0] == 401
        status, body = request(server, "GET", "/api/status", token=TOKEN)
        assert status == 200
        assert body["mode"] == "PAPER_ONLY"
        assert body["orders_authorized"] is False
    finally:
        server.shutdown(); server.server_close(); thread.join()


def test_emergency_stop_requires_auth_and_reason():
    server, thread, _, service = running_api()
    try:
        assert request(server, "POST", "/api/emergency-stop", {"reason": "test"})[0] == 401
        assert request(server, "POST", "/api/emergency-stop", {}, token=TOKEN)[0] == 400
        status, body = request(server, "POST", "/api/emergency-stop", {"reason": "operator requested"}, token=TOKEN)
        assert status == 200
        assert body["status"] == "EMERGENCY_STOP_ACTIVE"
        assert body["orders_authorized"] is False
        assert service.reasons == ["operator requested"]
    finally:
        server.shutdown(); server.server_close(); thread.join()


def test_api_token_must_be_long_enough():
    try:
        make_handler(state=RuntimeState.create(), service=FakeService(), api_token="short")
    except ValueError:
        pass
    else:
        raise AssertionError("weak token accepted")
