"""Token-authenticated read-only WSGI API for paper-ledger inspection.

Only GET routes exist. This module intentionally exposes no order, fill, control,
stop-clear, or exchange execution mutation endpoints. Deploy behind HTTPS.
"""
from __future__ import annotations

import hmac
import json
import os
import time
from typing import Callable, Iterable
from wsgiref.simple_server import make_server

from app.engines.paper_ledger import SQLitePaperLedger


def _json_bytes(value: object) -> bytes:
    return json.dumps(value, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _position_dict(p) -> dict[str, object]:
    return {
        "proposal_id": p.proposal_id, "symbol": p.symbol, "side": p.side,
        "quantity": p.quantity, "entry_price": p.entry_price, "mark_price": p.mark_price,
        "stop_loss": p.stop_loss, "take_profit": p.take_profit, "opened_at": p.opened_at,
        "mark_observed_at": p.mark_observed_at, "status": p.status,
        "opening_fee": p.opening_fee, "closing_fee": p.closing_fee,
        "funding_pnl": p.funding_pnl, "unrealized_pnl": p.unrealized_pnl,
        "total_pnl": p.total_pnl, "closed_at": p.closed_at,
    }


def create_app(*, database_path: str, token: str, market_status: Callable[[], dict] | None = None):
    """Create WSGI app. A strong API token is mandatory; no permissive defaults."""
    if not isinstance(token, str) or len(token) < 32:
        raise ValueError("API token must be at least 32 characters; configure it as a secret")
    if not database_path or database_path == ":memory:":
        raise ValueError("API requires a durable file-backed paper ledger")

    def app(environ, start_response):
        method = environ.get("REQUEST_METHOD", "GET").upper()
        path = environ.get("PATH_INFO", "/")
        if method != "GET":
            body, status = _json_bytes({"error": "method_not_allowed", "orders_authorized": False}), "405 Method Not Allowed"
        else:
            supplied = environ.get("HTTP_AUTHORIZATION", "")
            expected = "Bearer " + token
            if not hmac.compare_digest(supplied.encode("utf-8"), expected.encode("utf-8")):
                body, status = _json_bytes({"error": "unauthorized"}), "401 Unauthorized"
            elif path == "/api/v1/status":
                try:
                    with SQLitePaperLedger(database_path) as ledger:
                        feed = market_status() if market_status else {"status": "UNKNOWN", "orders_authorized": False}
                        payload = {
                            "service": "ai-auto-trader-v4", "mode": "PAPER_ONLY",
                            "orders_authorized": False, "emergency_stop_active": ledger.emergency_stop_active,
                            "emergency_stop_reason": ledger.emergency_stop_reason,
                            "open_position_count": len(ledger.open_positions), "feed": feed,
                            "server_time": time.time(),
                        }
                    body, status = _json_bytes(payload), "200 OK"
                except Exception:
                    body, status = _json_bytes({"error": "ledger_unavailable", "orders_authorized": False}), "503 Service Unavailable"
            elif path == "/api/v1/markets":
                # Market-worker state is not yet wired into this API process; do
                # not substitute a fabricated or cached-as-live market snapshot.
                body, status = _json_bytes({"status": "UNAVAILABLE", "items": [],
                    "reason": "market worker is not connected to the read-only API",
                    "orders_authorized": False}), "503 Service Unavailable"
            elif path in ("/api/v1/positions", "/api/v1/orders", "/api/v1/audit", "/api/v1/funding"):
                try:
                    with SQLitePaperLedger(database_path) as ledger:
                        if path.endswith("/positions"):
                            payload = {"items": [_position_dict(p) for p in ledger.positions], "orders_authorized": False}
                        elif path.endswith("/orders"):
                            payload = {"items": [vars_order(o) for o in ledger.orders], "orders_authorized": False}
                        elif path.endswith("/funding"):
                            payload = {"items": [dict(e) for e in ledger.funding_events], "orders_authorized": False}
                        else:
                            payload = {"items": [{"event_id": e.event_id, "event_type": e.event_type,
                                "proposal_id": e.proposal_id, "occurred_at": e.occurred_at,
                                "payload": dict(e.payload)} for e in ledger.audit_events()], "orders_authorized": False}
                    body, status = _json_bytes(payload), "200 OK"
                except Exception:
                    body, status = _json_bytes({"error": "ledger_unavailable"}), "503 Service Unavailable"
            elif path == "/api/v1/risk":
                try:
                    with SQLitePaperLedger(database_path) as ledger:
                        snapshots = ledger._connection.execute(
                            "SELECT * FROM paper_equity_snapshots ORDER BY snapshot_at DESC LIMIT 1"
                        ).fetchone()
                        payload = {"emergency_stop_active": ledger.emergency_stop_active,
                                   "open_position_count": len(ledger.open_positions), "orders_authorized": False,
                                   "latest_snapshot": dict(snapshots) if snapshots else None}
                    body, status = _json_bytes(payload), "200 OK"
                except Exception:
                    body, status = _json_bytes({"error": "ledger_unavailable"}), "503 Service Unavailable"
            else:
                body, status = _json_bytes({"error": "not_found"}), "404 Not Found"
        start_response(status, [("Content-Type", "application/json; charset=utf-8"),
                                ("Content-Length", str(len(body))), ("Cache-Control", "no-store"),
                                ("X-Content-Type-Options", "nosniff")])
        return [body]
    return app


def vars_order(order) -> dict[str, object]:
    return {"proposal_id": order.proposal_id, "signal_id": order.signal_id, "symbol": order.symbol,
            "side": order.side, "quantity": order.quantity, "entry_price": order.entry_price,
            "stop_loss": order.stop_loss, "take_profit": order.take_profit,
            "recorded_at": order.recorded_at, "status": order.status}


def main() -> None:
    token = os.environ.get("PAPER_API_TOKEN", "")
    database = os.environ.get("PAPER_DATABASE_PATH", "./data/paper-ledger.sqlite3")
    host = os.environ.get("PAPER_API_HOST", "127.0.0.1")
    port = int(os.environ.get("PAPER_API_PORT", "8080"))
    if host not in ("127.0.0.1", "localhost") and os.environ.get("PAPER_API_HTTPS_TERMINATED") != "1":
        raise SystemExit("Refusing non-loopback bind unless HTTPS termination is configured")
    with make_server(host, port, create_app(database_path=database, token=token)) as server:
        print(f"Read-only paper API listening on {host}:{port}; no execution routes")
        server.serve_forever()


if __name__ == "__main__":
    main()
