import json

import pytest

from app.engines.paper_ledger import SQLitePaperLedger
from app.engines.read_only_api import create_app

TOKEN = "unit-test-token-that-is-at-least-32-characters-long"


def request(app, path="/api/v1/status", method="GET", auth=None):
    captured = {}
    def start(status, headers):
        captured["status"] = status
        captured["headers"] = dict(headers)
    environ = {"REQUEST_METHOD": method, "PATH_INFO": path,
               "HTTP_AUTHORIZATION": auth or "", "wsgi.input": None}
    body = b"".join(app(environ, start))
    return captured["status"], captured["headers"], json.loads(body)


def test_api_requires_strong_token_and_reads_status(tmp_path):
    db = str(tmp_path / "ledger.sqlite3")
    with SQLitePaperLedger(db):
        pass
    app = create_app(database_path=db, token=TOKEN)
    status, _, body = request(app)
    assert status.startswith("401")
    status, headers, body = request(app, auth="Bearer " + TOKEN)
    assert status.startswith("200")
    assert body["mode"] == "PAPER_ONLY"
    assert body["orders_authorized"] is False
    assert headers["Cache-Control"] == "no-store"


def test_api_has_no_mutation_routes_and_rejects_non_get(tmp_path):
    db = str(tmp_path / "ledger.sqlite3")
    with SQLitePaperLedger(db):
        pass
    app = create_app(database_path=db, token=TOKEN)
    status, _, body = request(app, path="/api/v1/orders", method="POST", auth="Bearer " + TOKEN)
    assert status.startswith("405")
    assert body["orders_authorized"] is False
    status, _, body = request(app, path="/api/v1/place-order", auth="Bearer " + TOKEN)
    assert status.startswith("404")


def test_api_refuses_short_tokens_and_memory_database():
    with pytest.raises(ValueError):
        create_app(database_path="./ledger.sqlite3", token="short")
    with pytest.raises(ValueError):
        create_app(database_path=":memory:", token=TOKEN)
