package com.aiautotrader.v4

import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import org.json.JSONArray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// UI-only theme preference. This changes presentation only; it cannot affect trading or risk controls.
private var lightTheme by mutableStateOf(false)
private val Background: Color get() = if (lightTheme) Color(0xFFF7F5F0) else Color(0xFF0B1018)
private val Panel: Color get() = if (lightTheme) Color(0xFFFFFFFF) else Color(0xFF151D29)
private val PanelAlt: Color get() = if (lightTheme) Color(0xFFEEEAE1) else Color(0xFF1B2635)
private val Gold = Color(0xFFD8B878)
private val Green: Color get() = if (lightTheme) Color(0xFF087F5B) else Color(0xFF43D9A3)
private val Red: Color get() = if (lightTheme) Color(0xFFC6283D) else Color(0xFFFF6B78)
private val Muted: Color get() = if (lightTheme) Color(0xFF5D6672) else Color(0xFF9BA9BA)
private val White: Color get() = if (lightTheme) Color(0xFF202630) else Color(0xFFF4F7FB)
private val Grid: Color get() = if (lightTheme) Color(0xFFD4CEC2) else Color(0xFF2A3544)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (lightTheme) lightColorScheme(primary = Gold, background = Background, surface = Panel,
                onBackground = White, onSurface = White) else darkColorScheme(primary = Gold, background = Background, surface = Panel,
                onBackground = White, onSurface = White)) {
                Surface(Modifier.fillMaxSize(), color = Background) { TraderApp() }
            }
        }
    }
}

@Composable
private fun TraderApp() {
    var screen by remember { mutableStateOf("Dashboard") }
    val screens = listOf("Dashboard", "AI Agents", "Markets", "Positions", "Risk Center")
    Column(Modifier.fillMaxSize().background(Background)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("AI AUTO TRADER", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(screen, color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("v4", color = Muted, fontWeight = FontWeight.SemiBold)
                Tag("PAPER ONLY", Green)
                Text(if (lightTheme) "☾ DARK" else "☼ LIGHT", color = Gold, fontSize = 10.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.clickable { lightTheme = !lightTheme }.padding(vertical = 3.dp, horizontal = 5.dp))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            screens.forEach { item ->
                val selected = screen == item || (item == "Markets" && screen == "Charts & Analysis")
                Box(Modifier.background(if (selected) Gold.copy(alpha = .16f) else Panel, RoundedCornerShape(12.dp))
                    .border(1.dp, if (selected) Gold.copy(alpha = .8f) else Grid, RoundedCornerShape(12.dp))
                    .clickable { screen = if (item == "Markets") "Charts & Analysis" else item }.padding(horizontal = 13.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text(item, color = if (selected) Gold else Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        when (screen) {
            "Charts & Analysis", "Markets" -> AnalysisScreen()
            "AI Agents" -> AgentNetworkScreen()
            "Positions" -> PositionsScreen()
            "Risk Center" -> RiskCenterScreen()
            else -> DashboardScreen { screen = "Charts & Analysis" }
        }
    }
}

@Composable
private fun AgentNetworkScreen() {
    val agents = listOf(
        Triple("Research Agent", "Scans setups, support/resistance and market context", "READY · LOCAL UI"),
        Triple("Analysis Agent", "Reviews trend, momentum, volatility and indicators", "READY · LOCAL UI"),
        Triple("GAT Coordinator", "Designed to model relationships across instruments and agents", "NOT CONNECTED"),
        Triple("PPO / RL Policy", "Policy evaluation and learning from simulated outcomes", "NOT CONNECTED"),
        Triple("Risk Agent", "Checks sizing, exposure and trade constraints", "BACKEND REQUIRED"),
        Triple("Paper Simulator", "Simulated fills and position lifecycle", "BACKEND REQUIRED")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CardPanel {
            StatusLine("●", "ORCHESTRATOR · NOT CONNECTED", Color(0xFFFFC857))
            Text("Multi-agent coordination", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("This screen shows the intended agent topology. It does not claim agents are running or communicating until the backend is connected.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Agents", "6", "Defined roles", Modifier.weight(1f))
                MetricCard("Message bus", "OFFLINE", "No live messages", Modifier.weight(1f))
            }
        }
        SectionTitle("INTENDED AGENT NETWORK")
        CardPanel {
            Text("Signal and context layer", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AgentFlowNode("Research", "Market context", Modifier.weight(1f))
                Text("+", color = Muted, fontWeight = FontWeight.Bold)
                AgentFlowNode("Analysis", "Indicators", Modifier.weight(1f))
            }
            NetworkArrow("Signals are proposals only · not orders")
            AgentFlowNode("GAT Coordinator", "Relationship graph / agent context", Modifier.fillMaxWidth())
            NetworkArrow("Context passed to policy evaluation")
            AgentFlowNode("PPO / RL Policy", "Candidate action · offline / paper training", Modifier.fillMaxWidth())
            NetworkArrow("Every candidate must pass independent validation")
            AgentFlowNode("Risk Gate", "Final authority · fail closed", Modifier.fillMaxWidth(), warning = true)
            NetworkArrow("Only approved paper intents reach the simulator")
            AgentFlowNode("Paper Simulator / Ledger", "Simulated fills and reconciliation", Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text("Illustrative architecture only. Arrows describe the planned data flow; no agents or message bus are connected in this build.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        SectionTitle("AGENT STATUS")
        agents.forEach { (name, description, status) ->
            CardPanel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Tag(status, if (status.startsWith("READY")) Green else Color(0xFFFFC857))
                }
                Text(description, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        SectionTitle("COMMUNICATION CONTRACT")
        CardPanel {
            IndicatorRow("Message schema", "Versioned JSON · planned")
            IndicatorRow("Timeout / retries", "Fail closed · planned")
            IndicatorRow("Agent direct execution", "PROHIBITED")
            IndicatorRow("Risk gate final authority", "REQUIRED")
            IndicatorRow("Training mode", "Offline / paper only")
        }
    }
}

@Composable
private fun AgentFlowNode(title: String, subtitle: String, modifier: Modifier = Modifier, warning: Boolean = false) {
    Column(modifier.background(if (warning) Color(0xFFFFC857).copy(alpha = if (lightTheme) .12f else .08f) else PanelAlt, RoundedCornerShape(12.dp))
        .border(1.dp, if (warning) Color(0xFFFFC857).copy(alpha = .8f) else Grid, RoundedCornerShape(12.dp))
        .padding(horizontal = 12.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = if (warning) Color(0xFFFFC857) else White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
        Text(if (warning) "NOT CONNECTED · REQUIRED GATE" else "PLANNED · OFFLINE", color = if (warning) Color(0xFFFFC857) else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
    }
}

@Composable
private fun NetworkArrow(label: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("↓", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
    }
}

@Composable
private fun PositionsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CardPanel {
            StatusLine("●", "PAPER LEDGER NOT CONNECTED", Color(0xFFFFC857))
            Text("Positions & orders", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("No positions or orders are displayed because verified ledger data is not available. Sample trades are intentionally not fabricated.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Open positions", "—", "Awaiting ledger", Modifier.weight(1f))
            MetricCard("Pending orders", "—", "Paper service offline", Modifier.weight(1f))
        }
        SectionTitle("POSITION MONITOR")
        CardPanel {
            Text("No paper positions to display", fontWeight = FontWeight.SemiBold)
            Text("When the backend is connected, this area will show symbol, side, entry, current mark, unrealized P&L, stop-loss, take-profit and protection state.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        SectionTitle("ORDER SAFETY")
        CardPanel {
            SafetyRow("Live exchange orders", "DISABLED", Green)
            SafetyRow("Paper fill reconciliation", "NOT CONNECTED", Color(0xFFFFC857))
            SafetyRow("Unknown position state", "BLOCK NEW ORDERS", Red)
        }
    }
}

@Composable
private fun RiskCenterScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CardPanel {
            StatusLine("●", "FAIL-CLOSED MODE", Green)
            Text("Risk control center", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("The UI cannot approve trades. If risk validation, market data or position reconciliation is unavailable, the intended behavior is to reject new paper intents.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        SectionTitle("INDEPENDENT SAFEGUARDS")
        CardPanel {
            SafetyRow("Risk gate", "BACKEND REQUIRED", Color(0xFFFFC857))
            SafetyRow("Max risk / exposure limits", "NOT LOADED", Color(0xFFFFC857))
            SafetyRow("Stale-data rejection", "REQUIRED", Green)
            SafetyRow("Unknown account state", "BLOCK NEW ORDERS", Red)
            SafetyRow("Agent direct exchange access", "PROHIBITED", Green)
            SafetyRow("Live execution", "DISABLED", Green)
        }
        SectionTitle("EMERGENCY STOP")
        CardPanel {
            Text("Emergency stop requires an authenticated backend connection", fontWeight = FontWeight.SemiBold)
            Text("Use the authenticated backend connection card on the dashboard to activate the persistent paper stop. This is not a live-exchange kill switch; live orders remain disabled.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(disabledContainerColor = PanelAlt, disabledContentColor = Muted)) { Text("STOP CONTROL UNAVAILABLE") }
        }
        SectionTitle("RISK EVENT LOG")
        CardPanel { Text("No risk events received", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun ReadOnlyBackendConnectionCard() {
    var token by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("NOT CONNECTED") }
    var details by remember { mutableStateOf("Set the HTTPS API URL in Gradle property paperApiBaseUrl, then enter the API token for this session.") }
    var loading by remember { mutableStateOf(false) }
    var openPositions by remember { mutableStateOf("—") }
    var emergencyStop by remember { mutableStateOf("UNKNOWN") }
    var feedStatus by remember { mutableStateOf("UNKNOWN") }
    val scope = rememberCoroutineScope()

    CardPanel {
        Text("READ-ONLY BACKEND CONNECTION", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text("API: ${if (BuildConfig.PAPER_API_BASE_URL.isBlank()) "not configured" else BuildConfig.PAPER_API_BASE_URL}", color = Muted, fontSize = 11.sp)
        OutlinedTextField(value = token, onValueChange = { token = it }, label = { Text("Bearer API token") },
            singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        Button(enabled = !loading && token.length >= 32 && BuildConfig.PAPER_API_BASE_URL.startsWith("https://"),
            onClick = {
                loading = true
                status = "CHECKING"
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        try {
                            val base = BuildConfig.PAPER_API_BASE_URL.trimEnd('/')
                            fun get(path: String): Pair<Int, String> {
                                val connection = (URL("$base$path").openConnection() as HttpURLConnection)
                                try {
                                    connection.requestMethod = "GET"
                                    connection.connectTimeout = 5000
                                    connection.readTimeout = 5000
                                    connection.setRequestProperty("Authorization", "Bearer $token")
                                    connection.setRequestProperty("Accept", "application/json")
                                    val code = connection.responseCode
                                    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                                    return code to (stream?.bufferedReader()?.use { it.readText() }.orEmpty())
                                } finally { connection.disconnect() }
                            }
                            val (code, body) = get("/api/v1/status")
                            if (code == 401) {
                                Triple("UNAUTHORIZED", "Token rejected. Check the API token and try again.", null)
                            } else if (code !in 200..299) {
                                Triple("API ERROR ($code)", "The server did not return a valid status response.", null)
                            } else {
                                val json = JSONObject(body)
                                if (json.optString("mode") != "PAPER_ONLY" || json.optBoolean("orders_authorized", true)) {
                                    Triple("UNSAFE RESPONSE", "Backend response did not confirm paper-only mode; data was not accepted.", null)
                                } else {
                                    val (positionsCode, positionsBody) = get("/api/v1/positions")
                                    val positionsLabel = if (positionsCode in 200..299) "AVAILABLE" else "UNAVAILABLE"
                                    // Parse the list response as JSON too; reject malformed responses rather than
                                    // displaying an apparently connected state from a partial HTTP check.
                                    if (positionsCode in 200..299) JSONObject(positionsBody).optJSONArray("items") ?: JSONArray()
                                    val feed = json.optJSONObject("feed")?.optString("status", "UNKNOWN") ?: "UNKNOWN"
                                    val stop = if (json.optBoolean("emergency_stop_active", false)) "ACTIVE" else "INACTIVE"
                                    val summary = "Mode: PAPER ONLY · Open positions: ${json.optInt("open_position_count", 0)} · Positions API: $positionsLabel"
                                    Triple("CONNECTED · PAPER ONLY", summary, Triple(positionsLabel, stop, feed))
                                }
                            }
                        } catch (_: Exception) {
                            Triple("OFFLINE / ERROR", "Connection failed. Verify the HTTPS URL, hosting status, and network access.", null)
                        }
                    }
                    status = result.first
                    details = result.second
                    result.third?.let { summary ->
                        openPositions = summary.first
                        emergencyStop = summary.second
                        feedStatus = summary.third
                    }
                    loading = false
                }
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Background)) {
            Text(if (loading) "CHECKING…" else "CONNECT & LOAD STATUS")
        }
        Text(status, color = if (status.startsWith("CONNECTED")) Green else Color(0xFFFFC857), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(details, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
        if (status.startsWith("CONNECTED")) {
            Divider(color = Grid)
            IndicatorRow("Positions API", openPositions)
            IndicatorRow("Emergency stop", emergencyStop)
            IndicatorRow("Market feed", feedStatus)
            Button(
                enabled = !loading && emergencyStop != "ACTIVE",
                onClick = {
                    loading = true
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            try {
                                val base = BuildConfig.PAPER_API_BASE_URL.trimEnd('/')
                                val connection = (URL("$base/api/v1/emergency-stop").openConnection() as HttpURLConnection)
                                try {
                                    connection.requestMethod = "POST"
                                    connection.connectTimeout = 5000
                                    connection.readTimeout = 5000
                                    connection.doOutput = true
                                    connection.setRequestProperty("Authorization", "Bearer $token")
                                    connection.setRequestProperty("Content-Type", "application/json")
                                    connection.setRequestProperty("Accept", "application/json")
                                    connection.outputStream.use { it.write("{\"reason\":\"Emergency stop activated from Android app\"}".toByteArray(Charsets.UTF_8)) }
                                    val code = connection.responseCode
                                    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                                    val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                                    if (code in 200..299) {
                                        val json = JSONObject(response)
                                        if (json.optBoolean("emergency_stop_active", false) && !json.optBoolean("orders_authorized", true)) {
                                            "ACTIVE" to "Emergency stop activated. Paper orders remain disabled."
                                        } else "UNKNOWN" to "Server response did not confirm the stop; verify backend status."
                                    } else "UNKNOWN" to "Stop request failed (HTTP $code). Verify backend status."
                                } finally { connection.disconnect() }
                            } catch (_: Exception) {
                                "UNKNOWN" to "Could not confirm stop activation. Check connection and backend status."
                            }
                        }
                        emergencyStop = result.first
                        details = result.second
                        loading = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
            ) { Text(if (loading) "SENDING STOP…" else if (emergencyStop == "ACTIVE") "EMERGENCY STOP ACTIVE" else "ACTIVATE EMERGENCY STOP") }
        }
        Text("Token stays in memory for this screen session; do not use an exchange key here. Stop activation is one-way from this screen; clearing requires a separate protected process.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun DashboardScreen(openAnalysis: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ReadOnlyBackendConnectionCard()
        CardPanel {
            StatusLine("●", "BACKEND STATUS IS UNVERIFIED UNTIL CONNECTED", Color(0xFFFFC857))
            Spacer(Modifier.height(8.dp))
            Text("Paper mode only", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("The dashboard is waiting for the Python service. Live balances, positions, prices and P&L are unavailable until the authenticated API is connected.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        SectionTitle("ACCOUNT OVERVIEW")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Paper equity", "—", "Waiting for backend", Modifier.weight(1f))
            MetricCard("Daily P&L", "—", "No account data", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Open positions", "—", "Not available", Modifier.weight(1f))
            MetricCard("Market feed", "OFFLINE", "Not configured", Modifier.weight(1f))
        }
        CardPanel {
            Text("CHARTS & ANALYSIS", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Candlesticks, indicators, performance and AI market commentary", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
            Button(onClick = openAnalysis, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Background), modifier = Modifier.fillMaxWidth()) { Text("Open Charts & Analysis") }
        }
        SectionTitle("SAFETY CONTROLS")
        CardPanel {
            SafetyRow("Exchange order execution", "DISABLED", Green)
            SafetyRow("Risk gate", "BLOCKED · backend unavailable", Red)
            SafetyRow("Emergency stop", "NOT CONNECTED", Color(0xFFFFC857))
        }
        Text("Build milestone 2 · Charts and analysis UI. No exchange credentials are stored in this app. AI analysis is advisory; independent risk validation has final authority.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun AnalysisScreen() {
    var symbol by remember { mutableStateOf("BTC/USDT") }
    var timeframe by remember { mutableStateOf("15m") }
    var selectedTab by remember { mutableStateOf("Market") }
    val timeframes = listOf("1m", "5m", "15m", "1h", "4h", "1D")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CardPanel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MARKET CHART", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Text(symbol, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Tag("SAMPLE CHART", Gold)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("BTC/USDT", "ETH/USDT", "EUR/USD", "GBP/USD").forEach { s -> ChoiceChip(s, symbol == s) { symbol = s } }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                timeframes.forEach { t -> ChoiceChip(t, timeframe == t) { timeframe = t } }
            }
            Text("Illustrative candles only · no live market feed connected", color = Muted, fontSize = 11.sp)
            CandlestickChart(Modifier.fillMaxWidth().height(190.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                LegendDot("Volume", Gold)
                LegendDot("Entry marker", Green)
                LegendDot("Exit marker", Red)
                LegendDot("SL / TP", Muted)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Market", "Performance").forEach { t ->
                Box(Modifier.weight(1f).background(if (selectedTab == t) Gold.copy(alpha = .15f) else Panel, RoundedCornerShape(10.dp))
                    .border(1.dp, if (selectedTab == t) Gold else Grid, RoundedCornerShape(10.dp)).clickable { selectedTab = t }.padding(11.dp), contentAlignment = Alignment.Center) {
                    Text(t, color = if (selectedTab == t) Gold else Muted, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
            }
        }
        if (selectedTab == "Market") {
            SectionTitle("TECHNICAL ANALYSIS")
            CardPanel {
                IndicatorRow("EMA / SMA", "Awaiting candles")
                IndicatorRow("RSI", "— · no data")
                IndicatorRow("MACD", "— · no data")
                IndicatorRow("Bollinger Bands", "— · no data")
                IndicatorRow("ATR · volatility", "— · no data")
                IndicatorRow("VWAP", "— · no data")
                IndicatorRow("Support / resistance", "Not calculated")
                IndicatorRow("Trend / momentum", "Not calculated")
                IndicatorRow("Volume analysis", "Not calculated")
                IndicatorRow("Multi-timeframe", "Select 1m–1D · feed required")
            }
            SectionTitle("AI MARKET ANALYSIS")
            CardPanel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(symbol, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Tag("ADVISORY ONLY", Gold)
                }
                AnalysisValue("Trend", "NEUTRAL · unavailable", Muted)
                AnalysisValue("Momentum", "Unavailable", Muted)
                AnalysisValue("Volatility", "Unavailable", Muted)
                AnalysisValue("AI signal", "HOLD · no market data", Gold)
                AnalysisValue("Risk check", "BLOCKED", Red)
                Text("Reasoning: no authenticated market candles or backend analysis are available. The system must not infer a trade from missing data. AI commentary cannot override the independent risk gate.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else {
            SectionTitle("PERFORMANCE ANALYTICS")
            AnalyticsChartCard("Equity curve", "No paper ledger data connected", ChartKind.LINE)
            AnalyticsChartCard("P&L history", "No closed-trade history connected", ChartKind.BARS)
            AnalyticsChartCard("Drawdown", "Unavailable until equity history exists", ChartKind.LINE)
            AnalyticsChartCard("Win / loss distribution", "No completed trades", ChartKind.BARS)
            AnalyticsChartCard("Portfolio allocation", "No open paper positions", ChartKind.ALLOCATION)
            AnalyticsChartCard("Performance by strategy & symbol", "No strategy results connected", ChartKind.BARS)
        }
        Text("Data status: OFFLINE. Performance panels do not display invented account results. Chart examples are visual placeholders until the backend supplies validated data.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private enum class ChartKind { LINE, BARS, ALLOCATION }

@Composable
private fun AnalyticsChartCard(title: String, note: String, kind: ChartKind) {
    CardPanel {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(note, color = Muted, fontSize = 11.sp)
        EmptyChart(Modifier.fillMaxWidth().height(92.dp), kind)
    }
}

@Composable
private fun CandlestickChart(modifier: Modifier = Modifier) {
    // Clearly labelled illustrative values; never represented as live exchange prices.
    val candles = listOf(0.48f,0.43f,0.51f,0.38f,0.41f,0.33f,0.39f,0.30f,0.35f,0.27f,0.31f,0.22f,0.26f,0.18f,0.24f,0.15f,0.20f,0.12f)
    Canvas(modifier.background(Panel, RoundedCornerShape(10.dp)).padding(8.dp)) {
        val w = size.width; val h = size.height; val chartH = h * .76f
        for (i in 0..4) { val y = chartH * i / 4; drawLine(Grid, Offset(0f,y), Offset(w,y), 1f) }
        val step = w / candles.size
        candles.forEachIndexed { i, close ->
            val open = if (i == 0) .52f else candles[i-1]
            val high = minOf(open, close) - .055f
            val low = maxOf(open, close) + .055f
            val color = if (close < open) Green else Red
            val x = step * (i + .5f)
            drawLine(color, Offset(x, high * chartH), Offset(x, low * chartH), 2f)
            val top = minOf(open, close) * chartH
            val bottom = maxOf(open, close) * chartH
            drawRect(color, Offset(x-step*.26f, top), Size(step*.52f, maxOf(4f,bottom-top)))
            val volumeH = ((i * 7 % 9) + 2) / 11f * (h-chartH)
            drawRect(color.copy(alpha=.48f), Offset(x-step*.22f, chartH+(h-chartH-volumeH)), Size(step*.44f, volumeH))
        }
        // Illustrative stop and target guides; they are not active orders.
        drawLine(Red.copy(alpha=.8f), Offset(0f, chartH*.70f), Offset(w, chartH*.70f), 1.5f)
        drawLine(Green.copy(alpha=.8f), Offset(0f, chartH*.23f), Offset(w, chartH*.23f), 1.5f)
        drawCircle(Gold, 4f, Offset(w*.67f, chartH*.38f))
        drawCircle(Red, 4f, Offset(w*.86f, chartH*.27f))
    }
}

@Composable
private fun EmptyChart(modifier: Modifier, kind: ChartKind) {
    Canvas(modifier.background(PanelAlt, RoundedCornerShape(10.dp)).padding(8.dp)) {
        for (i in 0..3) drawLine(Grid, Offset(0f,size.height*i/3), Offset(size.width,size.height*i/3), 1f)
        if (kind == ChartKind.ALLOCATION) {
            drawCircle(Grid, radius = minOf(size.height*.35f, size.width*.12f), center = Offset(size.width/2,size.height/2), style = androidx.compose.ui.graphics.drawscope.Stroke(width=14f))
        } else if (kind == ChartKind.BARS) {
            val bw = size.width / 12f
            for (i in 0..7) {
                val bh = size.height * ((i*5%8)+1) / 10f
                drawRect(if (i%3==0) Red.copy(alpha=.6f) else Green.copy(alpha=.6f), Offset(bw*(i+2), size.height-bh), Size(bw*.55f,bh))
            }
        } else {
            val path = Path().apply {
                moveTo(0f,size.height*.72f); lineTo(size.width*.16f,size.height*.62f); lineTo(size.width*.31f,size.height*.68f)
                lineTo(size.width*.48f,size.height*.37f); lineTo(size.width*.64f,size.height*.48f); lineTo(size.width*.81f,size.height*.24f); lineTo(size.width,size.height*.30f)
            }
            drawPath(path, Muted.copy(alpha=.7f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=2.5f))
        }
    }
}

@Composable
private fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun SectionTitle(text: String) { Text(text, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }

@Composable
private fun MetricCard(title: String, value: String, note: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Muted, fontSize = 11.sp); Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(note, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun SafetyRow(label: String, status: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(status, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusLine(symbol: String, text: String, color: Color) { Row(verticalAlignment = Alignment.CenterVertically) { Text(symbol, color = color); Text("  $text", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold) } }

@Composable
private fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (selected) Gold.copy(alpha=.17f) else PanelAlt, RoundedCornerShape(9.dp)).border(1.dp, if (selected) Gold else Grid, RoundedCornerShape(9.dp)).clickable(onClick = onClick).padding(horizontal=11.dp, vertical=8.dp)) {
        Text(text, color=if(selected) Gold else Muted, fontSize=11.sp, fontWeight=FontWeight.SemiBold)
    }
}

@Composable
private fun Tag(text: String, color: Color) { Text(text, color=color, fontSize=9.sp, fontWeight=FontWeight.Bold, modifier=Modifier.background(color.copy(alpha=.12f), RoundedCornerShape(6.dp)).padding(horizontal=7.dp, vertical=5.dp)) }

@Composable
private fun LegendDot(label: String, color: Color) { Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(4.dp)) { Text("●", color=color, fontSize=8.sp); Text(label, color=Muted, fontSize=8.sp) } }

@Composable
private fun IndicatorRow(name: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
        Text(name, color=White, fontSize=12.sp); Text(value, color=Muted, fontSize=10.sp)
    }
}

@Composable
private fun AnalysisValue(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
        Text(label, color=Muted, fontSize=12.sp); Text(value, color=color, fontSize=11.sp, fontWeight=FontWeight.SemiBold)
    }
}
